# @hbk/dsh-opencode-local

把**本机真实的 opencode CLI** 桥接进 DSH（DeepSeek Harness）的插件。**不伪装**：直接复用你已安装、已登录的官方 CLI，对上游而言就是官方 CLI 在正常使用。全程 TypeScript，零原生依赖。

> 当前版本 **0.2.3**。对外 HTTP API 已**静默保留**（代码在、默认关闭、无设置界面、不再维护投入）——本说明不涉及它。

## 前置要求

- Windows；Node ≥ 20
- opencode CLI **v2.2.6** 已安装并**已登录**（TUI 里能正常对话即可）
- DSH **0.2.2-rc.1**，使用 **desktop profile**（`C:\Users\<你>\.dsh\profiles\desktop`）

## 安装 / 卸载 / 回退

1. 安装：`dsh plugin add hbk-dsh-opencode-local-0.2.3.tgz`（或 DSH 插件管理界面选择该 tgz），目标为 **desktop profile**。
2. **完全退出 DSH 再重开**（不是关窗口，是退出进程）。
3. 设置页出现 **opencode-local** 卡片即成功；模型选择器里出现免费模型。
4. 卸载：DSH 插件管理里移除本插件，完全退出重开。
5. 回退：历史包都在仓库 `plugin/` 目录——`0.2.2.tgz`（已验收）、`0.1.0.tgz`（原型）。装旧包同样需完全退出重开。

## 设置页

### 「可用模型」tab
- 只列**免费模型**（serve 成本元数据全 0 才列），显示上下文窗口（如 `1.05M`）。
- 每个模型一个**可见性复选框**，默认全可见；顶端按钮一键全选/全不选。勾掉的模型不进选择器。
- **刷新**只重新拉取模型元数据，**不发任何模型推理请求**（0.2.2 起探测功能已废除）。

### 「可用工具」tab
- **总开关默认关**：关闭时模型只能纯文本对话。
- 打开后按**动作白名单**放行：`shell / edit / read / webfetch / websearch / grep / glob` 逐项勾选；**完全允许** = 所有动作（含未列出的）。
- **每回合次数上限**默认 20（1–1000），防失控。
- 工具活动（`[工具]/[完成]/[失败]`）在 DSH 里**折叠为思考行**，可展开；正文不受影响。

### 思考档位
输入框右侧控件，档位来自当前模型实时上报的 `variants`；默认 default，无效选择自动回退 default。

## 数据与日志

| 位置 | 内容 |
| --- | --- |
| `~/.dsh-opencode-local/catalog.json` | 模型元数据缓存（无凭据） |
| `~/.dsh-opencode-local/serve.log` | 插件 serve 子进程输出（实测恒空，无旋转） |
| `~/.local/share/opencode/` | opencode 自己的数据库与日志，**凭据在这里，插件直接复用、不复制** |

## 注意事项

- **工具在你本机真实执行**（跑命令、读写文件）。白名单是风险手闸：只勾你信任的动作。
- 白名单**按动作、不按资源**：放行 `read` 后 `.env` 等敏感文件也可被读取；放行 `shell` 等于允许任意命令。请按需最小勾选。
- UI 未列出的动作（`external_directory`、`subagent`、`skill` 等）只能经「完全允许」放行；不勾 = 一律拒绝（安全方向）。
- 个别情况下工具审批回复失败会导致该回合挂起，看门狗约 120 秒后报超时错误，DSH 会自动重试（最多 4 次）。
- 错误消息可能带上游响应的前 300 字，仅显示给你本人。
- 插件自启的 serve 用 **4096 起**的端口；机器上常驻的 `opencode serve --service`（**28894**）是另一个进程，互不影响，别混。
- 对外 API 默认关闭、只听 127.0.0.1；其 token 在 DSH 配置中明文存储（宿主行为）。静默保留期间不建议开启。

## 故障速查

| 症状 | 处置 |
| --- | --- |
| 模型全显示不可用 | 那是 0.2.1 旧探测时代的固化缓存，0.2.2 起已废除探测；升级后点「刷新」即可。**不是额度用完、不是要重新登录** |
| 发对话 30 秒无首事件 / 流中断 120 秒 | 看门狗报错并重试；持续出现查 `serve.log` 与 opencode 自身日志 |
| 提示 restart budget exhausted | serve 连续重启 3 次失败；检查 opencode CLI 本体能否手动 `opencode serve` 启动 |
| 回合结束无任何正文（EMPTY_RESPONSE） | 可重试错误，DSH 自动重试；多发生于模型只输出了工具笔记的回合 |

## 构建（开发者）

```bash
cd plugin
npm install
npm run typecheck   # 双项目 tsc
npm run build       # tsdown → lib/
npm pack            # 生成 tgz（README 自动随包）
```

真实对话回归：`node docs/impl-harness/run-all.mjs`（h1–h4，对话预算 ≤4；运行产物在 temp/，可随时删）。